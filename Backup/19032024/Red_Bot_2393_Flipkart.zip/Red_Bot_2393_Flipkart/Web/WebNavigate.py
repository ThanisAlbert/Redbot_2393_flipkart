import time
from selenium.webdriver import Keys, ActionChains
from selenium.webdriver.support.wait import WebDriverWait
from Chromedriver.Chromedriver import Chromedriver
from Log.Log import Log
from Web.DeleteConsignment import deleteconsignment
from Web.ScheduleSlot import scheduleslot
from Web.UpdateTracker import UpdateTracker
from Web.WebWait import WebWait

class WebNavigate(WebWait,Log):

    def __init__(self,username,password):
        self.log = self.getLogger()
        self.chrome = Chromedriver(downloadpath="d:\\", headless=False)
        self.driver = self.chrome.chromedriver()
        self.username =username
        self.password = password
        self.wait = WebDriverWait(self.driver, 40)
        WebWait.__init__(self,self.wait)

    def login(self):

        while(True):

            try:

                self.wait = WebDriverWait(self.driver, 180)
                self.driver.maximize_window()
                #time.sleep(5)
                self.driver.get("https://vendorhub.flipkart.com/#/vendor-portal/home")
                self.log.info("Flipkart Page Loaded")
                self.wait_for_element_byid("username")
                time.sleep(5)
                self.driver.find_element_by_id("username").send_keys(self.username)
                self.wait_for_element_byid("password")
                time.sleep(2)
                self.driver.find_element_by_id("password").send_keys(self.password)
                time.sleep(2)

                self.wait_for_element_byxpath("//input[@id='select-vendor-VEN10806']")
                self.driver.find_element_by_xpath("//input[@id='select-vendor-VEN10806']").click()
                self.wait_for_element_byxpath("//button[contains(text(),'NEXT')]")
                self.driver.find_element_by_xpath("//button[contains(text(),'NEXT')]").click()
                self.driver.minimize_window()
                self.log.info("Logged in successfully")
                break

            except Exception as e:
                self.driver.close()
                self.chrome = Chromedriver(downloadpath="d:\\", headless=False)
                self.driver = self.chrome.chromedriver()
                self.wait = WebDriverWait(self.driver, 40)
                self.log.info("Tried Again ")

    def createconsignment(self,ponum,tracker_sht):

        self.ponum = ponum; self.tracker_sht = tracker_sht
        self.log.info(f"***************************{self.ponum}***********************************")
        self.driver.get("https://vendorhub.flipkart.com/#/operations/po/details/" + self.ponum)
        self.wait_for_element_byxpath("(//div[contains(text(), 'Status')])[2]/following-sibling::div[1]")
        status = self.driver.find_element_by_xpath("(//div[contains(text(), 'Status')])[2]/following-sibling::div[1]").text

        updatetracker = UpdateTracker(trackersht=self.tracker_sht)
        updatetracker.update_postatus(ponum,status)

        if status.strip().upper()=="APPROVED":
            while True:

                self.driver.get("https://vendorhub.flipkart.com/#/operations/po/details/" + self.ponum)

                while (True):
                    self.deleteconsignment = deleteconsignment(driver=self.driver, ponum=self.ponum)
                    consignment_present = self.deleteconsignment.delete()
                    if consignment_present == 0:
                        break
                    self.log.info(f"Consignment deleted successfully for {ponum}")

                self.driver.get("https://vendorhub.flipkart.com/#/operations/po/details/" + self.ponum)
                self.wait_for_element_byxpath("//button[contains(text(),'Create Consignment')]")
                self.driver.find_element_by_xpath("//button[contains(text(),'Create Consignment')]").click()
                updatetracker = UpdateTracker(trackersht=tracker_sht)

                try:  # if_consignment_creation_possible
                    self.wait = WebDriverWait(self.driver, 5)
                    self.wait_for_element_byxpath("//button[contains(text(),'Update Quantity')]")
                    self.driver.find_element_by_xpath("//button[contains(text(),'Update Quantity')]")
                    try:  # if_slots_not_available
                        self.wait_for_element_byxpath("//div[contains(text(),'There are no slots')]")
                        updatetracker.update_consignmentstatus(self.ponum, "No Slots Available")
                        self.log.info(f"No slots available for {ponum}")
                        self.deleteconsignment = deleteconsignment(driver=self.driver, ponum=self.ponum)
                        consignment_present = self.deleteconsignment.delete()
                        self.log.info(f"Consignment deleted successfully for {ponum}")
                        break
                    except Exception as e:  # if_slots_available
                        self.scheduleslot = scheduleslot(driver=self.driver,trackersht=self.tracker_sht, ponum=self.ponum)
                        self.scheduleslot.schedule()
                        updatetracker.update_consignmentstatus(self.ponum,"Consignment Drafted")
                        self.log.info(f"Consignment Created Successfully for {ponum}")
                        break
                except Exception as e:  # if_consignment_creation_not_possible
                    while (True):
                        self.deleteconsignment = deleteconsignment(driver=self.driver, ponum=self.ponum)
                        consignment_present = self.deleteconsignment.delete()
                        if consignment_present == 0:
                            break
                        self.log.info(f"Consignment deleted successfully for {ponum}")

























