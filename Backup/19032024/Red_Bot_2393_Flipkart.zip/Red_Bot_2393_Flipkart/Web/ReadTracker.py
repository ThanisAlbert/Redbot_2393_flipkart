from tkinter import messagebox
import openpyxl

from Log.Log import Log
from Web.UpdateTracker import UpdateTracker
from Web.WebNavigate import WebNavigate

class Tracker(Log):

    def __init__(self,tracker,username,password,label):
        self.tracker = tracker
        self.username = username
        self.password = password
        self.label = label
        self.log = self.getLogger()

    def read(self):
        tracker_wk = openpyxl.load_workbook(self.tracker)
        tracker_sht = tracker_wk['Sheet1']

        maxrow = 0 #validation required
        for i in range(2, 10000):
            if str(tracker_sht.cell(row=i, column=1).value).strip() != "None" and str(tracker_sht.cell(row=i, column=1).value).strip() != "":
                tracker_sht.cell(row=i, column=16).value=""
                tracker_sht.cell(row=i, column=17).value=""
                tracker_sht.cell(row=i, column=18).value=""
                tracker_sht.cell(row=i, column=19).value=""
                tracker_sht.cell(row=i, column=20).value=""
                maxrow = maxrow + 1

        tracker_wk.save(self.tracker)
        self.label.configure(text=str("Logging in "))
        self.label.update()

        flipkart = WebNavigate(username=self.username,password=self.password)
        flipkart.login()

        ponos=set()
        for i in range(2, maxrow + 2):
            ponos.add(tracker_sht.cell(row=i,column=2).value)

        i=1
        for pono in ponos:
            self.label.configure(text=str(f"Creating  {i} of {len(ponos)}"))
            self.label.update()
            try:
                flipkart.createconsignment(ponum=pono,tracker_sht=tracker_sht)
            except Exception as e:
                self.log.info("login_page_load_error")
                self.log.info(e)
                updatetracker = UpdateTracker(trackersht=tracker_sht)
                updatetracker.update_postatus(pono, "technicalissue")

            i=i+1

        tracker_wk.save(self.tracker)
        self.label.configure(text=str(f"Completed"))
        self.label.update()
        messagebox.showinfo('Info', 'Consignment Creation Completed!')






