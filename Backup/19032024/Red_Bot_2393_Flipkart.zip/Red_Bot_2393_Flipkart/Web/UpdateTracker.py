class UpdateTracker:

    def __init__(self,trackersht):
        self.trackersht = trackersht


    def update_po_consigmentstatus(self,pono,status):
        for i in range(2, 10000):
            if str(self.trackersht.cell(row=i, column=2).value).strip() == pono:
                self.trackersht.cell(row=i, column=16).value=status
                self.trackersht.cell(row=i, column=17).value = status

    def update_scheduleddate(self,pono,scheduleddate):
        for i in range(2, 10000):
            if str(self.trackersht.cell(row=i, column=2).value).strip() == pono:
                self.trackersht.cell(row=i, column=19).value=scheduleddate

    def update_consignmentstatus(self, pono, status):
        for i in range(2, 10000):
            if str(self.trackersht.cell(row=i, column=2).value).strip() == pono:
                self.trackersht.cell(row=i, column=17).value = status

    def update_postatus(self,pono,status):
        for i in range(2, 10000):
            if str(self.trackersht.cell(row=i, column=2).value).strip() == pono:
                self.trackersht.cell(row=i, column=16).value=status

    def get_availableqty(self,product):
        result=""
        for i in range(2, 10000):
            if str(self.trackersht.cell(row=i, column=6).value).strip() == product:
                result = self.trackersht.cell(row=i, column=15).value
        if result=="":
            return 0
        elif result is None:
            return 0
        else:
            return result

    def update_slottedqty(self,product,slottedqty):
        for i in range(2, 10000):
            if str(self.trackersht.cell(row=i, column=6).value).strip() == product:
                self.trackersht.cell(row=i, column=20).value=slottedqty


    def error(self,product):
        for i in range(2,10000):
            if str(self.trackersht.cell(row=i, column=6).value).strip() == product:
                self.trackersht.cell(row=i, column=20).value = "quantityerror"





